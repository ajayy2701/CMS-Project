const router=require('express').Router()
const upload=require('../helpers/multer')
const regc=require('../controllers/regcontroller')
const blogc=require('../controllers/blogcontroller')
const adminc=require('../controllers/admincontroller')



router.get('/dashboard',adminc.admin)

router.get('/delete/:id',adminc.delete)


module.exports=router