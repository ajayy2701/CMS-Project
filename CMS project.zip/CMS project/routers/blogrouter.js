const router=require('express').Router()
const blogc=require('../controllers/blogcontroller')
const session=require('../helpers/handlelogin')
const upload=require('../helpers/multer')



//all blogs

router.get('/',session,blogc.allblogs)

router.get('/userblog/:message',session,blogc.userblog)

//createblog
router.get('/create',session,blogc.addform)
router.post('/create',upload.single('img'),blogc.add)

//updateblog
router.get('/updateblog/:id',blogc.updateform)
router.post('/updateblog/:id',upload.single('img'),blogc.updateblog)

//deleteblog

router.get('/deleteblog/:id',blogc.deleteblog)
router.get('/moredetails/:id',blogc.more)



module.exports=router