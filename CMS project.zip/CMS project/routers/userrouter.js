const router=require('express').Router()
const upload=require('../helpers/multer')
const regc=require('../controllers/regcontroller')
const blogc=require('../controllers/blogcontroller')



router.get('/',regc.login)

router.get('/signuppage',regc.signupform)
router.post('/signuppage',regc.createaccount)
router.get('/emailverify/:id',regc.emailverification)
router.post('/',regc.logincheck)
router.get('/forgotform/:id',regc.forgotform)
router.post('/forgotform/:id',regc.forgotpassword)
router.get('/fmail',regc.forgotmailsend)
router.post('/fmail',regc.linksend)
router.get('/logout',regc.logout)



router.get('/profileupdate',regc.profile)
router.post('/profileupdate',upload.single('img'),regc.profileupdate)




module.exports=router