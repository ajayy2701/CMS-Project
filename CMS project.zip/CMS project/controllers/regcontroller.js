const Reg=require('../models/reg')
const nodemailer=require('nodemailer')
const bcrypt=require('bcrypt')




exports.signupform=(req,res)=>{
  try{
    res.render('signupform.ejs',{message:""})
  }catch(error){
    console.log(error.message)
  }
}

exports.createaccount=async(req,res)=>{
  try{
   const{email,pass}=req.body
    const usermail=await Reg.findOne({email:email})
    if(usermail==null){
    const hashpassword=await bcrypt.hash(pass,10)
   const record=new Reg({email:email,password:hashpassword})
   record.save()
  //console.log(hashpassword)
   const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    auth: {
      // TODO: replace `user` and `pass` values from <https://forwardemail.net>
      user: "ajaysolankiraj27@gmail.com",
      pass:"sbog aoyw brbx wbbl",
    }
  });
  console.log("conntected to smtp server")
  const info = await transporter.sendMail({
    from: 'ajaysolankiraj27@gmail.com', // sender address
    to: email, // list of receivers
    subject: "Verification mail from xyz.com", // Subject line
    //text: "Hello world?", // plain text body
    html: `<a href=http://localhost:5000/emailverify/${record.id}>click here to verify</a>`, // html body
  });
   res.render('signupform.ejs',{message:'Your account has created succusfully'})
    }
    else{
      res.render('signupform.ejs',{message:`${email} is already registred`})
    }
  }catch(error){
    console.log(error.message)
  }
}


exports.emailverification=async(req,res)=>{
  try{
    const id=req.params.id
    await Reg.findByIdAndUpdate(id,{status:'Active'})
    res.render('emailmessage.ejs')
  }
  catch(error){
    console.log(error.message)
  }

}
exports.login=(req,res)=>{
  try{
  res.render('login.ejs',{message:""})
  }
  catch(error){
    console.log(error.message)
  }
}

exports.logincheck=async(req,res)=>{
  try{
  const{email,pass}=req.body
  const logincheck=await Reg.findOne({email:email})
  if(logincheck!==null){
    const passcheck=await bcrypt.compare(pass,logincheck.password)
    console.log(passcheck)
    if(passcheck){

    if(logincheck.status=='Active'){ 

       req.session.username=logincheck.email
       req.session.userid=logincheck.id
       req.session.isAuth=true
      if(email!=='admin@gmail.com'){


    res.redirect("/blog/")}
    else{
      res.redirect('/admin/dashboard')
    }
    }else{
      res.render('login.ejs',{message:"Please verify your account"})
    }
    }else{
      res.render('login.ejs',{message:"Wrong Credentials"})
    }
  }
  else{
     res.render('login.ejs',{message:"Wrong Credentials"})
  }
 } catch(error){
    console.log(error.message)
  }
}

exports.forgotform=(req,res)=>{
  try{
  console.log(req.params.id)
  res.render('forgotform.ejs',{message:''})
  }catch(error){
    console.log(error.message)
  }
}
exports.forgotpassword=async(req,res)=>{
  try{
  const{npass,cpass}=req.body
  const id=req.params.id
  if(npass==cpass){
  const newpassword=await bcrypt.hash(npass,10)
  await Reg.findByIdAndUpdate(id,{password:newpassword})
  res.render('forgotmessage.ejs')
  }else{
    res.render('forgotform.ejs',{message:'you paswword not matched'})
  }
}catch(error){
  console.log(error.message)
}
}

exports.forgotmailsend=(req,res)=>{
  try{
  res.render('fmail.ejs',{message:''})
  }catch(error){
    console.log(error.message)
  }
}

exports.linksend=async(req,res)=>{
  try{
  const{email}=req.body
  const emailvalidate= await Reg.findOne({email:email})
  if(emailvalidate!==null){
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      
      auth: {
        // TODO: replace `user` and `pass` values from <https://forwardemail.net>
        user: "ajaysolankiraj27@gmail.com",
        pass:"sbog aoyw brbx wbbl",
      }
    });
    console.log("conntected to smtp server")
    const info = await transporter.sendMail({
      from: 'ajaysolankiraj27@gmail.com', // sender address
      to: email, // list of receivers
      subject: "Password change link", // Subject line
      //text: "Hello world?", // plain text body
      html: `<a href=http://localhost:5000/forgotform/${emailvalidate.id}>click here to verify</a>`, // html body
    });
    res.render('fmail.ejs',{message:"link has sent please check your mail id"})


  }
  else{
    res.render('fmail.ejs',{message:'please registred your mail id'})

  }
}catch(error){
  console.log(error.message)
}
  
}

exports.logout=(req,res)=>{
  try{
  req.session.destroy()
  res.redirect('/')
  }catch(error){
    console.log(error.message)
  }
}

exports.profile=async(req,res)=>{
  try{
  username=req.session.username
  const userdata=await Reg.findOne({email:username})
  res.render('profileform.ejs',{username,userdata})
  }catch(error){
    console.log(error.message)
  }
}

exports.profileupdate = async (req, res) => {
  try{
  const username = req.session.username;
 const id= req.session.userid

  const { fname, lname,mobile ,gender,desc,img} = req.body;
  // console.log(id)
   //console.log("ID:", id);
   //console.log("First Name:", fname);
   //console.log("Last Name:", lname);
//console.log(req.body)  
console.log(mobile)
        if(img){
  await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mobile,gender,desc:desc,img:img})
        }
        else{
          await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mobile,gender,desc:desc})
        }
    res.redirect('/profileupdate')
      }catch(error){
        console.log(error.message)
      }
}
