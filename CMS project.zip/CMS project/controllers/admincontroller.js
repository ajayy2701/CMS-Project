const Blog=require('../models/blog')



exports.admin=async(req,res)=>{
    try{
    const username=req.session.username
    const record=await Blog.find()
    res.render("admin.ejs",{username,record})
}catch(error){
    console.log(error.message)
}
}


exports.delete=async(req,res)=>{
    try{
    const id=req.params.id
    await Blog.findByIdAndDelete(id)
    res.redirect('/admin/dashboard')
    }catch(error){
        console.log(error.message)
    }
}