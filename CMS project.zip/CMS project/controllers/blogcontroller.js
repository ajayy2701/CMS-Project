const Blog=require('../models/blog')



exports.allblogs=async(req,res)=>{
    try{
    const username=req.session.username
    const allblog= await Blog.find().sort({postedDate:-1})
    res.render('blog.ejs',{username,allblog})
    }catch(error){
        console.log(error.message)
    }
}

exports.userblog=async(req,res)=>{
    try{
    let message=req.params.message
    const username=req.session.username
    const userblog=await Blog.find({username:req.session.username}).sort({postedDate:-1})
    res.render('userblog.ejs',{username,userblog,message})
}catch(error){
    console.log(error.message)
}
}

exports.addform=(req,res)=>{
    try{
    const username=req.session.username
    res.render('addblogform.ejs',{username,message:''})
}catch(error){
    console.log(error.message)
}
}

exports.add=(req,res)=>{
    try{
    const username=req.session.username
    const{title,desc,mdesc}=req.body
    const filename=req.file.filename
    
    const newblog=new Blog({title:title,desc:desc,moredesc:mdesc,img:filename,username:username})
    newblog.save()
    //console.log(newblog)
    res.render('addblogform.ejs',{username,message:'your blog succucfully added'})
}catch(error){
    console.log(error.message)
}
   
}


exports.updateform=async(req,res)=>{
    try{
    const id=req.params.id
    username=req.session.username
    const blogrecord=await Blog.findById(id)
    res.render('updateform.ejs',{username,blogrecord})
}catch(error){
    console.log(error.message)
}
}


exports.updateblog=async(req,res)=>{
    try{
    const id=req.params.id
   
     let message="succucfully updated"
    const{title,desc,mdesc}=req.body
    if(req.file){
        const filename=req.file.filename
    await Blog.findByIdAndUpdate(id,{title:title,desc:desc,moredesc:mdesc,img:filename})
    }
    else{
        await Blog.findByIdAndUpdate(id,{title:title,desc:desc,moredesc:mdesc})  
    }
    res.redirect(`/blog/userblog/${message}`)
}catch(error){
    console.log(error.message)
}
}

exports.deleteblog=async(req,res)=>{
    try{
    let message="successfully deleted"
    const id=req.params.id
    await Blog.findByIdAndDelete(id)
    res.redirect(`/blog/userblog/${message}`)
}catch(error){
    console.log(error.message)
}
}


exports.more=async(req,res)=>{
    try{
    username=req.session.username
    const id=req.params.id
    const record=await Blog.findById(id)
    res.render('moredetails.ejs',{username,record})
}catch(error){
    console.log(error.message)
}
}