const mongoose=require('mongoose')


const blogSchema=mongoose.Schema({
    title:{type:String,required:true},
    desc:{type:String,required:true},
    moredesc:String,
    img:String,
    postedDate:{type:Date,default:new Date().toLocaleString(),required:true},
    username:{type:String,required:true}
})




module.exports=mongoose.model('blog',blogSchema)