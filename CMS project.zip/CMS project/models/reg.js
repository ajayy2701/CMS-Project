const mongoose=require('mongoose')


const regSchema=mongoose.Schema({
    email:{type:String,required:true},
    password:{type:String,required:true},
    firstName:{type:String, default:null},
    lastName:{type:String, default:null},
    mobile:{type:Number,default:null},
    gender:String,
    desc:String,
    img:String,
    status:{type:String,default:'Suspended'},
    createdDate:{type:String,default:new Date()}
})



module.exports=mongoose.model('reg',regSchema)